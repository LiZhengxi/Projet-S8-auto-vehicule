//------------------------------------------------------------------------------
// Name: 				Bus Slave
//
// Description: 		Shall allow SPI communication between MSP430G2553 (MASTER)
//						and MSP430G2231 (SLAVE).
//
// Authors:				Paul Bouquet / Paul Mocquillon
//
// Date of creation: 	02/03/2017
//
// Version: 			1.8
//------------------------------------------------------------------------------

#include "msp430g2231.h"


#include "Driver_Motor_IR.h"
#include "init.h"

//------------------------------------------------------------------------------
// main: 	call each init functions and wait for ever.
//------------------------------------------------------------------------------
int main(void)
{
  WDTCTL = WDTPW + WDTHOLD;             // Stop watchdog timer

  InitPort();							// Initialize Ports
  Motor_IR_Init();						// Set pwm for ir motor

  //_BIS_SR(LPM0_bits + GIE);   		// Enter LPM0 w/ interrupt

  while(1){
          TACCR1 = 1000; // set to 0 deg
          __delay_cycles(TIME_TO_CHECK);
          TACCR1 = 2000;  // set to 45 deg
          __delay_cycles(TIME_TO_CHECK);

  }
}

//------------------------------------------------------------------------------
// USI_VECTOR: 	interruption when SPI buffer is updated
//------------------------------------------------------------------------------
